<?php return array('dependencies' => array('react', 'react-dom'), 'version' => '3bd66fe8ff9e7426b485');
